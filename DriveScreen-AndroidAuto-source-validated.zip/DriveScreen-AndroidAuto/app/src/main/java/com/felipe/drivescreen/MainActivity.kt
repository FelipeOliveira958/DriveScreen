package com.felipe.drivescreen

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 72, 48, 48)
            setBackgroundColor(android.graphics.Color.rgb(11, 18, 32))
        }
        val title = TextView(this).apply {
            text = "DriveScreen"
            textSize = 30f
            setTextColor(android.graphics.Color.WHITE)
        }
        val message = TextView(this).apply {
            text = "Player de músicas para Android Auto\n\nPermita o acesso aos arquivos de áudio para que suas músicas apareçam na central multimídia."
            textSize = 17f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 28, 0, 28)
        }
        val status = TextView(this).apply {
            textSize = 15f
            setTextColor(android.graphics.Color.rgb(56, 189, 248))
        }
        layout.addView(title)
        layout.addView(message)
        layout.addView(status)
        setContentView(layout)
        if (ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED) {
            status.text = "Acesso às músicas autorizado. Conecte o celular ao Android Auto."
        } else {
            status.text = "Solicitando permissão para acessar músicas…"
            ActivityCompat.requestPermissions(this, arrayOf(audioPermission), 1001)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            recreate()
        }
    }
}
