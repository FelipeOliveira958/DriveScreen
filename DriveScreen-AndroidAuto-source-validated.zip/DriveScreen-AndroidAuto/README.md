# DriveScreen — Android Auto (mídia)

Projeto Android nativo inicial para disponibilizar músicas locais do telefone como uma biblioteca de mídia para o Android Auto, usando AndroidX Media3 (`MediaLibraryService`, `MediaLibrarySession` e ExoPlayer).

## Incluído
- Declaração da categoria de mídia do Android Auto (`automotive_app_desc.xml`).
- Solicitação da permissão de áudio no telefone.
- Leitura de faixas locais via MediaStore.
- Biblioteca paginada para o cliente de mídia do Android Auto.
- Workflow Codemagic que verifica Gradle e gera APK de depuração.

## Limitações desta versão
- Não incorpora Google Maps ou Waze; a navegação continua no app de navegação escolhido.
- Não controla Spotify ou YouTube Music.
- Não lê bateria, autonomia ou dados do veículo Geely.
- APK de depuração não significa aprovação/disponibilidade automática no Android Auto; é necessário compilar, instalar e validar em aparelho e multimídia reais, além de cumprir os requisitos de qualidade e distribuição aplicáveis.

## Build
O workflow usa o Gradle instalado no ambiente Android do Codemagic (`gradle --no-daemon clean assembleDebug`). O projeto ainda não contém Gradle Wrapper. Se o ambiente de build não disponibilizar Gradle no PATH, o log indicará a falha e será necessário adicionar o wrapper.
